
// Sa se calculeze pi pentru incercari=1000000000 in mai putin de 3 secunde
let incercari=1000000000;
for(let i=0; i<incercari; i++)
{
    let.worker = new Worker('worker.js');
    worker.onmessage = event =>{
        document.body.innerHTML += event.data[1];
        document.body.innerHTML += "<br>";
    }
}
